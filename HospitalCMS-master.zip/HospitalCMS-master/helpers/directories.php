<?php

	/*********************************************************************************************
	 * PROJECT DIRECTORIES
     *********************************************************************************************/

	$css = 'assets/css/';
	$js = 'assets/js/';
	$font = 'assets/fonts/';
	$img = 'assets/images/';
	$ico = 'assets/icons/';
	$empImg = 'public/employees_thumbnails/';
	$patImg = 'public/patients_thumbnails/';
